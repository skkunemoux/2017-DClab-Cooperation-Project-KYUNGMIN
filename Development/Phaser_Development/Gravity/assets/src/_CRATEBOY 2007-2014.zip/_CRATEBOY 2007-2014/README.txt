There's lots of stuff in there to enjoy and use. Lots of it has potential for cool projects other stuff were my first things I ever made, its really a mixed bag! I'm sure if you dig in there enough there's something for everyone whether its to use as is, remix, recolor, test, use as place holders or just generate ideas. Its all creative commons, you just have to use the stuff in good spirit, give credit where credit is due, don't pass it off as your own and don't sell it. You can use the stuff for commercial projects but consider donating or buy me a beer IDK. Have fun and let me know if you use anything!
Cheers,
Crateboy

https://creativecommons.org/licenses/by/4.0/